#stylesheets
Rails.application.config.assets.precompile += %w( )

#javascripts
Rails.application.config.assets.precompile += %w( controllers/vehicle_report_cards.js )