# Preview all emails at http://localhost:3000/rails/mailers/vehicle_report_card_mailer
class VehicleReportCardMailerPreview < ActionMailer::Preview

end
