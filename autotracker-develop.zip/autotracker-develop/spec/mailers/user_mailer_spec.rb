require "rails_helper"

describe UserMailer, :type => :mailer do
end
