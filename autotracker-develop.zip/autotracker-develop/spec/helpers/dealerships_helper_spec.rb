require 'rails_helper'
RSpec.describe DealershipsHelper, type: :helper do
end
