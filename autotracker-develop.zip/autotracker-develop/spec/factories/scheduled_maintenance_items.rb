FactoryGirl.define do
  factory :scheduled_maintenance_item do
    
  end
end
