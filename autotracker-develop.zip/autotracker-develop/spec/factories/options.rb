FactoryGirl.define do
  factory :option do
    
  end
end
