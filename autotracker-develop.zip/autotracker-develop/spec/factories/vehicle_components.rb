FactoryGirl.define do
  factory :vehicle_component do
    
  end
end
