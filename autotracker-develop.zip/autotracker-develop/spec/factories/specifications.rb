FactoryGirl.define do
  factory :specification do
    
  end
end
