FactoryGirl.define do
  factory :equipments_inventory do
    
  end
end
