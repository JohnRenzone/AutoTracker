FactoryGirl.define do
  factory :equipment do
    
  end
end
