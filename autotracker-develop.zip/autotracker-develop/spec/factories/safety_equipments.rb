FactoryGirl.define do
  factory :safety_equipment do
    
  end
end
