FactoryGirl.define do
  factory :inventories_specification do
    
  end
end
