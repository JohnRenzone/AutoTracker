FactoryGirl.define do
  factory :inventories_option do
    
  end
end
