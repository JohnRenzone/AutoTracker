FactoryGirl.define do
  factory :epa_green_score_record do
    
  end
end
