FactoryGirl.define do
  factory :color do
    
  end
end
