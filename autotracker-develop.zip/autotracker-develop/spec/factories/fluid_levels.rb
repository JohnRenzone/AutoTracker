FactoryGirl.define do
  factory :fluid_level do
    vehicle_report_card

  end
end
