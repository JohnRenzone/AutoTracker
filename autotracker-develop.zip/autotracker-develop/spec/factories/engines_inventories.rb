FactoryGirl.define do
  factory :engines_inventory do
    
  end
end
