FactoryGirl.define do
  factory :tire_wear_indicate do
    
  end
end
