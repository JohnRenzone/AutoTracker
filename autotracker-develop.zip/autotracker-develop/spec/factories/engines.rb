FactoryGirl.define do
  factory :engine do
    
  end
end
