FactoryGirl.define do
  factory :transmission do
    
  end
end
