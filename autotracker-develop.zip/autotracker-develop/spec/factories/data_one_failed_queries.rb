FactoryGirl.define do
  factory :data_one_failed_query do
    
  end
end
