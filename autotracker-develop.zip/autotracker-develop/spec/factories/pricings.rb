FactoryGirl.define do
  factory :pricing do
    
  end
end
