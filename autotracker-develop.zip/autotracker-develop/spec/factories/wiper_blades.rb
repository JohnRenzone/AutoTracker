FactoryGirl.define do
  factory :wiper_blade do
    
  end
end
