FactoryGirl.define do
  factory :battery do
    
  end
end
