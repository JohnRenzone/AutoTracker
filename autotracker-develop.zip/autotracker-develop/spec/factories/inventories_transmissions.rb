FactoryGirl.define do
  factory :inventories_transmission do
    
  end
end
