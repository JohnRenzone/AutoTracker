FactoryGirl.define do
  factory :brake_wear_indicate do
    
  end
end
