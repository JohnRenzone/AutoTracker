FactoryGirl.define do
  factory :data_one_error_message do
    
  end
end
