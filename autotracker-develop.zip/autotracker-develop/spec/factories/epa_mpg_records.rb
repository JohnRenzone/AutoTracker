FactoryGirl.define do
  factory :epa_mpg_record do
    
  end
end
