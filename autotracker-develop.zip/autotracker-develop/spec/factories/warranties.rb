FactoryGirl.define do
  factory :warranty do
    
  end
end
