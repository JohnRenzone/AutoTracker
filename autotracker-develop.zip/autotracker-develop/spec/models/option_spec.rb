require 'rails_helper'

RSpec.describe Option, type: :model do
  let(:option) { create(:option) }
end
