require 'rails_helper'

RSpec.describe InventoriesSpecification, type: :model do
  let(:inventories_specification) { create(:inventories_specification) }
end
