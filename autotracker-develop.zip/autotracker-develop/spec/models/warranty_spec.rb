require 'rails_helper'

RSpec.describe Warranty, type: :model do
  let(:warranty) { create(:warranty) }
end
