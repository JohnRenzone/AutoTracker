require 'rails_helper'

RSpec.describe EpaGreenScoreRecord, type: :model do
  let(:epa_green_score_record_spec) { create(:epa_green_score_record_spec) }
end
