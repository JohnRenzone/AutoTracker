require 'rails_helper'

RSpec.describe EpaMpgRecord, type: :model do
  let(:epa_mpg_record) { create(:epa_mpg_record) }
end
