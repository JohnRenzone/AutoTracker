require 'rails_helper'

RSpec.describe Equipment, type: :model do
  let(:equipment) { create(:equipment) }
end
