require 'rails_helper'

RSpec.describe Engine, type: :model do
  let(:engine) { create(:engine) }
end
