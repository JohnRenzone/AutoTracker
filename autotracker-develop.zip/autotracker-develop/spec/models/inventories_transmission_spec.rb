require 'rails_helper'

RSpec.describe InventoriesTransmission, type: :model do
  let(:inventories_transmission) { create(:inventories_transmission) }
end
