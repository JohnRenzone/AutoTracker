require 'rails_helper'

RSpec.describe SafetyEquipment, type: :model do
  let(:safety_equipment) { create(:safety_equipment) }
end
