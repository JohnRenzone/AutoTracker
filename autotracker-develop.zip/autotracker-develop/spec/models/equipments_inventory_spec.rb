require 'rails_helper'

RSpec.describe EquipmentsInventory, type: :model do
  let(:equipments_inventory) { create(:equipments_inventory) }
end
