require 'rails_helper'

RSpec.describe Pricing, type: :model do
  let(:pricing) { create(:pricing) }
end
