require 'rails_helper'

RSpec.describe Specification, type: :model do
  let(:specification) { create(:specification) }
end
