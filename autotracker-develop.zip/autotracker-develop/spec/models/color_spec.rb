require 'rails_helper'

RSpec.describe Color, type: :model do
  let(:color) { create(:color) }
end
