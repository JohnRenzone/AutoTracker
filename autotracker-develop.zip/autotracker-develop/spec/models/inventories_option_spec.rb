require 'rails_helper'

RSpec.describe InventoriesOption, type: :model do
  let(:inventories_option) { create(:inventories_option) }
end
