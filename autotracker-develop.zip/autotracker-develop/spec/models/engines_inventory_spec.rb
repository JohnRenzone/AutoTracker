require 'rails_helper'

RSpec.describe EnginesInventory, type: :model do
  let(:engines_inventory) { create(:engines_inventory) }
end
