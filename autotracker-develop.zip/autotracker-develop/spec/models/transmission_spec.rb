require 'rails_helper'

RSpec.describe Transmission, type: :model do
  let(:transmission) { create(:transmission) }
end
