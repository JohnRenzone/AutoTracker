require 'rails_helper'

RSpec.describe DataOneErrorMessage, type: :model do
  let(:data_one_error_message) { create(:data_one_error_message) }
end
