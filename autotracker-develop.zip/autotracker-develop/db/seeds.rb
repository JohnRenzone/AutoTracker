user = User.create!(email: 'admin@example.com',
                   password: 'demouser',
                   password_confirmation: 'demouser',
                   first_name: 'Master',
                   last_name: 'Admin',
                   role: 0 )