class InteriorColor < Color
end