class RoofColor < Color
end