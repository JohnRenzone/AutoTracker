class DataOneQueryErrorMessage < DataOneErrorMessage

end
