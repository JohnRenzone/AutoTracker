class ExteriorColor < Color
end