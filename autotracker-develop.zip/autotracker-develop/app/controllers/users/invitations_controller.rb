class Users::InvitationsController < Devise::InvitationsController
  protected

end