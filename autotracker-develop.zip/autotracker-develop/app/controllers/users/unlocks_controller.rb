class Users::UnlocksController < Devise::PasswordsController
end
